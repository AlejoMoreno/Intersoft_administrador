<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Clasificaciones extends Model
{
    //
    protected $fillable = ['nombre','descripcion','codigo_interno'];
}
