<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contabilidades extends Model
{
    //
}
