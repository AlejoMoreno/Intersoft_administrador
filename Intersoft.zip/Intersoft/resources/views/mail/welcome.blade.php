<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
    <title>Bienvenida a usuario Intersoft</title>
</head>
<body>
    <p>Hola Intersoft quiere darte la bienvenida</p>
    <p>Estos son los datos del usuario:</p>
    <ul>
        <li></li>
    </ul>
</body>
</html>