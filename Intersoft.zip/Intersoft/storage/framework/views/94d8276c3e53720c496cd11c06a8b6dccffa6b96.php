<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<link rel="icon" type="image/png" href="http://wakusoft.com/img/works/thumbs/1.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Intersoft</title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <!-- Bootstrap core CSS     -->
    <link href="<?php echo e(public_path('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />

    <link  href="<?php echo e(public_path('assets/css/pdfstyle.css')); ?>" rel="stylesheet"/>
</head>
    <div class="container">
        <h1>Reporte Diario Contable</h1>
        <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>tipo_documento</th>
                        <th>sucursal</th>
                        <th>numero_documento</th>
                        <th>prefijo</th>
                        <th>valor_transaccion</th>
                        <th>tipo_transaccion</th>
                        <th>cuenta</th>
                        <th>descripcion</th>
                        <th>tercero</th> 
                        <th>razon_social</th>
                        <th>fecha_documento</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                            <td><?php echo e($obj['tipo_documento']); ?></td>
                            <td><?php echo e($obj['sucursal']); ?></td>
                            <td><?php echo e($obj['numero_documento']); ?></td>
                            <td><?php echo e($obj['prefijo']); ?></td>
                            <td><?php echo e($obj['valor_transaccion']); ?></td>
                            <td><?php echo e($obj['tipo_transaccion']); ?></td>
                            <td><?php echo e($obj['cuenta']); ?></td>
                            <td><?php echo e($obj['descripcion']); ?></td>
                            <td><?php echo e($obj['tercero']); ?></td> 
                            <td><?php echo e($obj['razon_social']); ?></td>
                            <td><?php echo e($obj['fecha_documento']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
    </div>
