<?php $__env->startSection('content'); ?>

<style>
    .title{
        margin-left: 2%;
        font-weight: bold;
        font-family: Poppins;
    }
    .top-5-w{
        margin-top:5%;
    }
    .table > thead th {
        -webkit-animation: pantallain 100s infinite; /* Safari 4.0 - 8.0 */
        -webkit-animation-direction: alternate; /* Safari 4.0 - 8.0 */
        animation: pantallain 100s infinite;
        animation-direction: alternate;
    }
</style>
    

<div class="enc-article">
    <h4 class="title">Liquidación de comisión</h4>
</div>

<div class="row top-11-w" style="padding:2%;">

    <div class="panel panel-default col-md-5" >
        <!-- Default panel contents -->
        <div class="panel-heading row"><h5>Filtros de búsqueda</h5></div>
        <div class="panel-body" >
            <p style="font-size: 10pt;">
                Utilice los filtros de búsqueda necesarios para realizar la liquidación.
            </p>
            <div class="row">
                <div class="col-md-6">
                    <input type="number" id="valor" value="<?php echo e($valor); ?>" name="valor" placeholder="porcentaje (%) comisión" class="form-control"><br>
                </div>   
                <div class="col-md-6">
                    <select id="estado" class="form-control">
                        <option value="FACTURADO">FACTURADO</option>
                        <option value="ACTIVO">ACTIVO</option>
                        <option value="DEVUELTO">DEVUELTO</option>
                    </select>
                </div>
                <br>  
                <hr>
                <p>Seleccione el vendedor: </p>
                <br>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12" style="margin:2%;">
                    <div class="btn-success" style="padding:3%;color:white;" onclick="verUsuarioVentas(<?php echo e($obj['id']); ?>)">
                        <?php echo e($obj['ncedula']); ?> / <?php echo e($obj['correo']); ?>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="col-md-7 row">
        <div class="panel panel-warning col-md-12" >
            <!-- Default panel contents -->
            <div class="panel-heading row" >
                <h5 class="col-md-4">Resultado de Facturas</h5>
            </div>
            <div class="panel-body" style="overflow-x:scroll;">
                <p style="font-size: 10pt;">
                    Resultado de la busqueda
                </p>
                <?php  $total = 0; ?>
                <table class="table table-hover table-striped"  id="tabla">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Tercero</th>
                        <th>Fecha ___Emisión___</th>
                        <th>Fecha Vencimiento</th>
                        <th>subtotal</th>
                        <th>iva</th>
                        <th>impoconsumo</th>
                        <th>impuesto 1</th>
                        <th>impuesto 2</th>
                        <th>descuento</th>
                        <th>fletes</th>
                        <th>retefuente</th>
                        <th>total</th>
                        <th>Saldo Cartera</th>
                        <th>Estado</th>
                        <th>Fecha creado</th>
                        <th>Fecha Actualizado</th>
                    </tr></thead>
                    <tbody>
                    
                        <?php if($facturas!=null): ?>
                            <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $total = $total + ( ($obj['subtotal']*$valor)/100 );  ?>
                            <tr>
                                <td><a href="javascript:envioUrl('/documentos/imprimir/<?php echo e($obj['id']); ?>')" class="btn btn-success"><?php echo e($obj['numero']); ?></a></td>
                                <td><?php echo e($obj['id_tercero']); ?></td>
                                <td><?php echo e($obj['fecha']); ?></td>
                                <td><?php echo e($obj['fecha_vencimiento']); ?></td>
                                <td><?php echo e(number_format($obj['subtotal'])); ?></td>
                                <td><?php echo e(number_format($obj['iva'])); ?></td>
                                <td><?php echo e(number_format($obj['impoconsumo'])); ?></td>
                                <td><?php echo e(number_format($obj['otro_impuesto'])); ?></td>
                                <td><?php echo e(number_format($obj['otro_impuesto_1'])); ?></td>
                                <td><?php echo e(number_format($obj['descuento'])); ?></td>
                                <td><?php echo e(number_format($obj['fletes'])); ?></td>
                                <td><?php echo e(number_format($obj['retefuente'])); ?></td>
                                <td><?php echo e(number_format($obj['total'])); ?></td>
                                <td><?php echo e(number_format($obj['saldo'])); ?></td>
                                <td><?php echo e($obj['estado']); ?></td>
                                <td><?php echo e($obj['created_at']); ?></td>
                                <td><?php echo e($obj['updated_at']); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
                        <?php endif; ?>                       
                    </tbody>
                </table>
            </div>
            <?php if($total!=0): ?>
                <h2>Calculo total de comisión con valor <?php echo e($valor); ?>(%) es: <?php echo e($total); ?> </h2>
            <?php endif; ?>
        </div>
    </div>

</div>




<script>
function verUsuarioVentas(id){
    valor = $('#valor').val();
    estado = $('#estado').val();
    config.Redirect('/facturacion/liquidacionventas/'+id+'/'+valor+'?estado='+estado);
}
function envioUrl(url){
    window.open(url, "imprimir documento", "width=800, height=700")
}


</script>

<script>
    $(document).ready(function() {
        var table = $('#tabla').DataTable( {
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]
        } );
    });
    </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>