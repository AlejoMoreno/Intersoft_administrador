<?php $__env->startSection('content'); ?>

<?php 


?>

<div class="container-fluid">
    <div class="row">

        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h4 class="title">Lotes</h4>
                    <p class="category">Diferentes Lotes</p><br>
                </div>
                <div class="content">
                    <div style="overflow-x:scroll;overflow-y:scroll;height:500px;">
                        <table class="table table-hover table-striped" id="datos">
                            <thead>
                                <tr>
                                    <th>ID</th> 
                                    <th>Producto</th>
                                    <th>Número Lote</th> 
                                    <th>Fecha vencimiento</th>
                                    <th>Ubicación</th>
                                    <th>Serie</th>
                                    <th>Cantidad</th>
                                    <th>Sucursal</th>
                                    <th></th> 
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $lotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="row<?php echo e($obj['id']); ?>">
                                        <td><?php echo e($obj['id']); ?></td> 
                                        <td><?php echo e($obj['id_referencia']['descripcion']); ?></td>
                                        <td><?php echo e($obj['numero_lote']); ?></td> 
                                        <td><?php echo e($obj['fecha_vence_lote']); ?></td>
                                        <td><?php echo e($obj['ubicacion']); ?></td>
                                        <td><?php echo e($obj['serie']); ?></td>
                                        <td><?php echo e($obj['cantidad']); ?></td>
                                        <td><?php echo e($obj['id_sucursal']['nombre']); ?></td>
                                        <!--td><a href="javascript:;" onclick="lotes.update('<?php echo e($obj); ?>');"><button class="btn btn-warning">></button></a></td--!>
                                        <!--td><a onclick="config.delete_get('/inventario/lotes/delete/', '<?php echo e($obj); ?>',  '/inventario/lotes');" href="#"><button class="btn btn-danger">x</button></a></td-->
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th></th> 
                                    <th></th>
                                    <th></th> 
                                    <th></th>
                                    <th></th>
                                    <th>Total</th>
                                    <th><?php echo $number ?></th>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>
                        <?php echo e($lotes->links()); ?>

                    </div>

                    

                    <div id="resultado"></div>
                    <div class="footer">
                        <div class="legend">
                            <i class="fa fa-circle text-info"></i> 
                            <i class="fa fa-circle text-danger"></i> 
                            <i class="fa fa-circle text-warning"></i>
                        </div>
                        <hr>
                        <div class="stats">
                            <i class="pe-7s-angle-left-circle"></i> <a href="#" onclick="config.Redirect('/inventario/index');"> ir atras.</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">
    lotes.initial();
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>