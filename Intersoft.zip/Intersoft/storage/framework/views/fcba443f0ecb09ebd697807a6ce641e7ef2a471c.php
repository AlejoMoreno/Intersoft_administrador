<?php $__env->startSection('content'); ?>



<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h4 class="title">Consulta de Documentos </h4>
                    <p class="category">Elige que quieres hacer</p>
                </div>
                <div class="content">
                    <div style="width: 100%;overflow: scroll;"> 
                        <table class="table table-hover table-striped"  id="datos">
                            <thead>
                                <th>Documento</th>
                                <th>Sucursal</th>
                                <th>#</th>
                                <th>Tercero</th>
                                <th>Nombre</th>
                                <th>Fecha ___Emisión___</th>
                                <th>Fecha Vencimiento</th>
                                <th>subtotal</th>
                                <th>iva</th>
                                <th>impoconsumo</th>
                                <th>impuesto 1</th>
                                <th>impuesto 2</th>
                                <th>descuento</th>
                                <th>fletes</th>
                                <th>retefuente</th>
                                <th>total</th>
                                <th>Saldo Cartera</th>
                                <th>Estado</th>
                                <th>Fecha creado</th>
                                <th>Fecha Actualizado</th>
                                <th></th>
                                <th></th>
                            </tr></thead>
                            <tbody>
                                <?php $__currentLoopData = $factura; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($obj->id_documento->nombre); ?> <?php echo e($obj->prefijo); ?></td>
                                    <td><?php echo e($obj->id_sucursal->nombre); ?></td>
                                    <td><a href="javascript:envioUrl('/documentos/imprimir/<?php echo e($obj->id); ?>')" class="btn btn-success"><?php echo e($obj->numero); ?></a></td>
                                    <td><?php echo e($obj->id_tercero); ?></td>
                                    <td><?php echo e($obj->id_cliente->razon_social); ?></td>
                                    <td><?php echo e($obj->fecha); ?></td>
                                    <td><?php echo e($obj->fecha_vencimiento); ?></td>
                                    <td><?php echo e(number_format($obj->subtotal)); ?></td>
                                    <td><?php echo e(number_format($obj->iva)); ?></td>
                                    <td><?php echo e(number_format($obj->impoconsumo)); ?></td>
                                    <td><?php echo e(number_format($obj->otro_impuesto)); ?></td>
                                    <td><?php echo e(number_format($obj->otro_impuesto_1)); ?></td>
                                    <td><?php echo e(number_format($obj->descuento)); ?></td>
                                    <td><?php echo e(number_format($obj->fletes)); ?></td>
                                    <td><?php echo e(number_format($obj->retefuente)); ?></td>
                                    <td><?php echo e(number_format($obj->total)); ?></td>
                                    <td><?php echo e(number_format($obj->saldo)); ?></td>
                                    <td><?php echo e($obj->estado); ?></td>
                                    <td><?php echo e($obj->created_at); ?></td>
                                    <td><?php echo e($obj->updated_at); ?></td>
                                    <td><div onclick="config.anular('factura','<?php echo e($obj); ?>')" href="/documentos/anular/<?php echo e($obj->id); ?>" class="btn btn-warning">> Anular</div></td>
                                    <td><div onclick="config.eliminar('factura','<?php echo e($obj); ?>')" href="/documentos/eliminar/<?php echo e($obj->id); ?>" class="btn btn-danger">X Eliminar</div></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                            </tbody>
                        </table>
                        <?php echo e($factura->links()); ?>

                    </div>
                    <div class="footer">
                        <div class="legend">
                            <i class="fa fa-circle text-info"></i> 
                            <i class="fa fa-circle text-danger"></i> 
                            <i class="fa fa-circle text-warning"></i>
                        </div>
                        <hr>
                        <div class="stats">
                            <i class="pe-7s-angle-left-circle"></i> <a href="#" onclick="config.Redirect('/index');"> ir atras.</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script language=javascript>
function envioUrl (url){
window.open(url, "imprimir documento", "width=800, height=700")
}
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>