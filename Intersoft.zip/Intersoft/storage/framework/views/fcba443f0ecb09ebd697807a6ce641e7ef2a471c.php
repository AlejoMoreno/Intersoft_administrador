<?php $__env->startSection('content'); ?>


<div class="enc-article">
    <h4 class="title">Consulta de documentos</h4>
</div>

<div class="row top-11-w">
    <br><br>
    <p style="font-size:10pt;font-family:Poppins;margin-left:2%">Filtros de busqueda:</p>
    <div class="col-md-12"> 
        <form method="GET" class="row">
            <div class="col-md-2">
                <input type="text" name="nit" placeholder="Nit" value="<?php echo e(isset($_GET['nit'])?$_GET['nit']:''); ?>" class="form-control">
            </div>
            <div class="col-md-4">
                <div class="col-md-12 row">
                    <div class="col-md-8">
                        <input type="text" name="razonsocial" value="<?php echo e(isset($_GET['razonsocial'])?$_GET['razonsocial']:''); ?>" placeholder="Razón social" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <select class="form-control" name="vendedor" id="vendedor"> 
                            <option value="">Vendedor</option>
                            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($obj['id']); ?>"><?php echo e($obj['nombre']); ?> <?php echo e($obj['apellido']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 row">
                <div class="col-md-6">
                    <input type="date" name="fechainicio" value="<?php echo e(isset($_GET['fechainicio'])?$_GET['fechainicio']:date('Y-m-d')); ?>" class="form-control">
                </div>
                <div class="col-md-6">
                    <input type="date" name="fechafinal" value="<?php echo e(isset($_GET['fechafinal'])?$_GET['fechafinal']:date('Y-m-d')); ?>" class="form-control">
                </div>
            </div>
            <div class="col-md-2">
                <input type="submit" value="Consultar" class="btn btn-success">
            </div>
        </form><br><br>
    </div>
    <div class="col-md-11" style="overflow-x:scroll;margin-left:2%">
        <table class="table table-hover table-striped"  id="datos">
            <thead>
                <th>Documento</th>
                <th>Sucursal</th>
                <th>#</th>
                <th>Nit</th>
                <th>Nombre</th>
                <th>Fecha Emisión</th>
                <th>Fecha Vencimiento</th>
                <th>subtotal</th>
                <th>iva</th>
                <th>impoconsumo</th>
                <th>impuesto 1</th>
                <th>impuesto 2</th>
                <th>descuento</th>
                <th>fletes</th>
                <th>retefuente</th>
                <th>total</th>
                <th>Saldo Cartera</th>
                <th>Estado</th>
                <th>Vendedor</th>
                <th>Fecha creado</th>
                <th></th>
                <th></th>
            </tr></thead>
            <tbody>
                <?php $__currentLoopData = $factura; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($obj['nombre']); ?> <?php echo e($obj['prefijo']); ?></td>
                    <td><div style="width: 150px;"><?php echo e($obj['sucunombre']); ?></div></td>
                    <td><a href="javascript:envioUrl('/documentos/imprimir/<?php echo e($obj['idfactura']); ?>')" ><?php echo e($obj['numero']); ?></a></td>
                    <td><?php echo e($obj['id_tercero']); ?></td>
                    <td><div style="width: 200px;"><?php echo e($obj['nombrecliente']); ?></div></td>
                    <td><?php echo e($obj['fecha']); ?></td>
                    <td><?php echo e($obj['fecha_vencimiento']); ?></td>
                    <td><?php echo e(number_format($obj['subtotal'])); ?></td>
                    <td><?php echo e(number_format($obj['iva'])); ?></td>
                    <td><?php echo e(number_format($obj['impoconsumo'])); ?></td>
                    <td><?php echo e(number_format($obj['otro_impuesto'])); ?></td>
                    <td><?php echo e(number_format($obj['otro_impuesto_1'])); ?></td>
                    <td><?php echo e(number_format($obj['descuento'])); ?></td>
                    <td><?php echo e(number_format($obj['fletes'])); ?></td>
                    <td><?php echo e(number_format($obj['retefuente'])); ?></td>
                    <td><?php echo e(number_format($obj['total'])); ?></td>
                    <td><?php echo e(number_format($obj['saldo'])); ?></td>
                    <td><?php echo e($obj['estadofactura']); ?></td>
                    <td><?php echo e($obj['nombrevendedor']); ?> <?php echo e($obj['apellido']); ?></td>
                    <td><div style="width: 150px;"><?php echo e($obj['creado']); ?></div></td>
                    <td><div onclick="config.anular('factura','<?php echo e($obj); ?>')" href="/documentos/anular/<?php echo e($obj['idfactura']); ?>" class="btn btn-warning"><i style="font-size: 12px;" class="fas fa-ban"></i></div></td>
                    <td><div onclick="config.eliminar('factura','<?php echo e($obj); ?>')" href="/documentos/eliminar/<?php echo e($obj['idfactura']); ?>" class="btn btn-danger"><i style="font-size: 12px;" class="fas fa-trash"></i></div></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
            </tbody>
        </table>
    </div>
    
</div>



<script language=javascript>

$(document).ready( function () {
    $('#datos').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ] 
    });
} );

function envioUrl (url){
window.open(url, "imprimir documento", "width=800, height=700")
}
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>