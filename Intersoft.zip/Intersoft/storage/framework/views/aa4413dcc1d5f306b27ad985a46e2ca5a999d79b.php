<?php $__env->startSection('content'); ?>

<?php 

$referencia = App\Referencias::where('id','=',$kardex[0]->id_referencia->id)->first();

?>

<div class="container-fluid">
    <div class="row">

        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h4 class="title">Kardex <small style="color:white;">Código: </small> <?php echo e($referencia->codigo_linea . $referencia->codigo_letras . $referencia->codigo_consecutivo); ?></h4>
                    <p class="category"> <br><?php echo e($referencia->descripcion); ?> // saldo: <?php echo e($referencia->saldo); ?></p>
                </div>
                <div class="content">
                    <div style="overflow-x: scroll;"> 
                    <table class="table table-hover table-striped">
                                    <thead>
                                    <tr>
                                        <th>Documento</th>
                                        <th>Sucursal</th>
                                        <th>#</th>
                                        <th>Tercero</th>
                                        <th>cantidad</th>
                                        <th>precio compra/venta</th>
                                        <th>Saldo</th>
                                    </tr></thead>
                                    <tbody>
                                    	<?php $cont = 0; $total = 0; ?>
                                    	<tr><td></td><td></td><td></td><td><?php echo e($cont); ?></td><td><?php echo e($total); ?></td></tr>
                                       <?php $__currentLoopData = $kardex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php 

                                       if($obj->signo == "+"){
                                       		$cont = $cont + $obj->cantidad;
                                       		$total = $total + ( -($obj->total*2)+ $obj->total);
                                       }
                                       else if($obj->signo == "-"){
                                       		$cont = $cont - $obj->cantidad;
                                       		$total = $total - ( -($obj->total*2)+ $obj->total);
                                       }
                                       else{
                                       		$cont = $cont;
                                       		$total = $total;
                                       }

                                       ?>
                                       <tr>
                                       <td><?php echo e($obj->id_documento->nombre); ?> <?php echo e(' Pref. '. $obj->prefijo); ?>

	                                       </td>
	                                       <td><?php echo e($obj->id_sucursal->nombre); ?></td>
	                                       <td><a href="javascript:envioUrl('/documentos/imprimir/<?php echo e($obj->cabecera[0]->id); ?>')" class="btn btn-success"><?php echo e($obj->numero); ?></a></td>
	                                       <td><?php echo e($obj->cabecera[0]->id_tercero); ?></td>
	                                       <td><?php echo e(number_format($obj->cantidad)); ?></td>
	                                       <td><?php echo e(number_format($obj->total)); ?></td>
	                                       <td><?php echo e(number_format($cont)); ?></td>	
	                                    </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <?php echo e($kardex->links()); ?>

                            </div>
                    <div class="footer">
                        <div class="legend">
                            <i class="fa fa-circle text-info"></i> 
                            <i class="fa fa-circle text-danger"></i> 
                            <i class="fa fa-circle text-warning"></i>
                        </div>
                        <hr>
                        <div class="stats">
                            <i class="pe-7s-angle-left-circle"></i> <a href="#" onclick="window.close();"> ir atras.</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script language=javascript>
function envioUrl (url){
window.open(url, "imprimir documento", "width=600, height=500")
}
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>