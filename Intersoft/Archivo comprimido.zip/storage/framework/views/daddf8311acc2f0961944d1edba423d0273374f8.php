<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<link rel="icon" type="image/png" href="http://wakusoft.com/img/works/thumbs/1.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title>Intersoft</title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <!-- Bootstrap core CSS     -->
    <link href="<?php echo e(public_path('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />

    <link  href="<?php echo e(public_path('assets/css/pdfstyle.css')); ?>" rel="stylesheet"/>
</head>
    <div class="container">
        <h1>Referencias</h1>
        <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Codigo</th>
                        <th>Descripcion</th>
                        <th>Conteo</th>
                        <th>Kardex</th>
                        <th>sobra</th>
                        <th>falta</th>
                        <th>costo</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                            <td><?php echo e($obj['codigo']); ?></td>
                            <td><?php echo e($obj['descripcion']); ?></td>
                            <td><?php echo e($obj['conteo']); ?></td>
                            <td><?php echo e($obj['saldo']); ?></td>
                            <td><?php echo e($obj['sobra']); ?></td>
                            <td><?php echo e($obj['falta']); ?></td>
                            <td><?php echo e($obj['costo']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
    </div>