<?php $__env->startSection('content'); ?>


<style>
.title{
    margin-left: 2%;
    font-weight: bold;
    font-family: Poppins;
}
.top-5-w{
    margin-top:5%;
}
.table > thead th {
    -webkit-animation: pantallain 100s infinite; /* Safari 4.0 - 8.0 */
    -webkit-animation-direction: alternate; /* Safari 4.0 - 8.0 */
    animation: pantallain 100s infinite;
    animation-direction: alternate;
}
</style>

<div class="enc-article">
    <h4 class="title">Extracto clientes / proveedores</h4>
</div>

<br><br>
<div class="row top-11-w">
    
    <div class="panel panel-primary " style="margin-left:5%;margin-right:5%;">
        <!-- Default panel contents -->
        <div class="panel-heading">Extracto clientes</div>
        <div class="panel-body" >
            <p style="font-size: 10pt;">A continuación se describe el extracto de los clientes, en el cual se detalla
                el saldo diferente de 0 (cero) de cada uno de las facturas emitidas con corte
                al presente día. <br> <strong style="font-size: 20pt;">TOTAL : $ <span style="font-size: 20pt;" id="total_cliente"></span></strong>
            </p>
        </div>

        <!-- Table -->
        <div style="overflow-x:scroll;">
            <table class="table table-hover" id="tabla_cliente">
                <thead>
                    <tr>
                        <th>NIT</th>
                        <th>RAZÓN SOCIAL</th>
                        <th>TELÉFONO</th>
                        <th>ZONA VENTA</th>
                        <th>FECHA FACTURA</th>
                        <th>FECHA VENCIMIENTO</th>
                        <th>NUMERO</th>
                        <th>PREFIJO</th>
                        <th>VENDEDOR</th>
                        <th>SALDO</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $carteracliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(number_format($obj->nit, 0, ",", ".")); ?></td>
                        <td><?php echo e($obj->razon_social); ?></td>
                        <td><?php echo e($obj->telefono); ?></td>
                        <td><?php echo e($obj->zona_venta); ?></td>
                        <td><?php echo e($obj->fecha); ?></td>
                        <td><?php echo e($obj->fecha_vencimiento); ?></td>
                        <td><?php echo e($obj->numero); ?></td>
                        <td><?php echo e($obj->prefijo); ?></td>
                        <td><?php echo e(number_format($obj->ncedula, 0, ",", ".")); ?></td>
                        <td><?php echo e($obj->saldo); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>


    <div class="panel panel-warning " style="margin-left:5%;margin-right:5%;">
        <!-- Default panel contents -->
        <div class="panel-heading">Extracto proveedores</div>
        <div class="panel-body" >
            <p style="font-size: 10pt;">A continuación se describe el extracto de los proveedores, en el cual se detalla
                el saldo diferente de 0 (cero) de cada uno de las facturas emitidas con corte
                al presente día. <br> <strong style="font-size: 20pt;">TOTAL : $ <span style="font-size: 20pt;" id="total_proveedor"></span></strong>
            </p>
        </div>

        <!-- Table -->
        <div style="overflow-x:scroll;">
            <table class="table table-hover" id="tabla_proveedor">
                <thead>
                    <tr>
                        <th>NIT</th>
                        <th>RAZÓN SOCIAL</th>
                        <th>TELÉFONO</th>
                        <th>ZONA VENTA</th>
                        <th>FECHA COMPRA</th>
                        <th>FECHA VENCIMIENTO</th>
                        <th>NUMERO</th>
                        <th>PREFIJO</th>
                        <th>SALDO</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $carteraproveedor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(number_format($obj->nit, 0, ",", ".")); ?></td>
                        <td><?php echo e($obj->razon_social); ?></td>
                        <td><?php echo e($obj->telefono); ?></td>
                        <td><?php echo e($obj->zona_venta); ?></td>
                        <td><?php echo e($obj->fecha); ?></td>
                        <td><?php echo e($obj->fecha_vencimiento); ?></td>
                        <td><?php echo e($obj->numero); ?></td>
                        <td><?php echo e($obj->prefijo); ?></td>
                        <td><?php echo e($obj->saldo); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

</div>





<script>
$(document).ready(function() {
    var table = $('#tabla_cliente').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
    var table2 = $('#tabla_proveedor').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );

    totalclientes(table);
    totalproveedor(table2);

    $('input[aria-controls=tabla_cliente]').keypress(function(){
        totalclientes(table);
    });
    
    $('input[aria-controls=tabla_proveedor]').keypress(function(){
        totalproveedor(table2);
    });

} );


function totalclientes(table){
    var total = 0;
    var data = table.rows().data();
    data.each(function (value, index){
        total = total + parseInt(value[9]);
    });
    $('#total_cliente').text(total);
}

function totalproveedor(table){
    var total = 0;
    var data = table.rows().data();
    data.each(function (value, index){
        total = total + value[9];
    });
    $('#total_proveedor').text(total);
}

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>