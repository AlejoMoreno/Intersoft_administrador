<?php $__env->startSection('content'); ?>

<div class="enc-article">
    <h4 class="title">Vista de lotes</h4>
</div>

<div class="row top-5-w">
<p style="font-size:10pt;font-family:Poppins;margin-left:2%">Observa los lotes con su ubicación y fecha de vencimiento por cada uno de los productos que se 
    encuentran en el sistema.</p>
    <div class="col-md-11" style="margin-left:2%">
        <table class="table table-hover table-striped" id="datos">
            <thead>
                <tr>
                    <th>ID</th> 
                    <th>Producto</th>
                    <th>Número Lote</th> 
                    <th>Fecha vencimiento</th>
                    <th>Ubicación</th>
                    <th>Serie</th>
                    <th>Cantidad</th>
                    <th>Sucursal</th>
                    <th></th> 
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $lotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="row<?php echo e($obj['id']); ?>">
                        <td><?php echo e($obj['id']); ?></td> 
                        <td><?php echo e($obj['id_referencia']['descripcion']); ?></td>
                        <td><?php echo e($obj['numero_lote']); ?></td> 
                        <td><?php echo e($obj['fecha_vence_lote']); ?></td>
                        <td><?php echo e($obj['ubicacion']); ?></td>
                        <td><?php echo e($obj['serie']); ?></td>
                        <td><?php echo e($obj['cantidad']); ?></td>
                        <td><?php echo e($obj['id_sucursal']['nombre']); ?></td>
                        <td></td>
                        <!--td><a href="javascript:;" onclick="lotes.update('<?php echo e($obj); ?>');"><button class="btn btn-warning">></button></a></td--!>
                        <!--td><a onclick="config.delete_get('/inventario/lotes/delete/', '<?php echo e($obj); ?>',  '/inventario/lotes');" href="#"><button class="btn btn-danger">x</button></a></td-->
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <h2 style="margin: 2%;padding-top:2%;">Total cantidades: <?php echo $number ?></h2>
    
</div>




<script>
$(document).ready( function () {
    $('#datos').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ] 
    });
} );
</script>



<script type="text/javascript">
    lotes.initial();
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>