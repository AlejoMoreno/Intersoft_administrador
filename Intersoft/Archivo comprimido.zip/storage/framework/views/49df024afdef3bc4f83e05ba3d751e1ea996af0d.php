<?php $__env->startSection('content'); ?>

<style>
    .title{
        margin-left: 2%;
        font-weight: bold;
        font-family: Poppins;
    }
    .top-5-w{
        margin-top:5%;
    }
    .table > thead th {
        -webkit-animation: pantallain 100s infinite; /* Safari 4.0 - 8.0 */
        -webkit-animation-direction: alternate; /* Safari 4.0 - 8.0 */
        animation: pantallain 100s infinite;
        animation-direction: alternate;
    }

    .container {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  padding: 0 10px;
}
 
#dt-table_wrapper {
  width: 35%;
  margin-right: 2%;
}
 
#chart {
  width: 63%;
}
 
table {
  text-align: left;
}
 
@media  screen and (max-width: 1200px) {
  #dt-table_wrapper,
  #chart {
    width: 100%;
  }
 
  #dt-table_wrapper {
    margin-right: 0;
  }
}
</style>
    

<div class="enc-article">
    <h4 class="title">Estadisticas de ventas</h4>
</div>

<div class="row top-11-w" style="padding:2%;">

    <div class="panel panel-default col-md-5" >
        <!-- Default panel contents -->
        <div class="panel-heading row"><h5>Filtros de busqueda</h5></div>
        <div class="panel-body" >
            <p style="font-size: 10pt;">A contiuación se describe la lista de usuarios y demás datos 
                para el filtro de busqueda.
            </p>
        </div>
        <form class="row" method="GET" action="">
            <label class="col-md-2">Desde:</label>
            <div class="col-md-4">
                <input type="date" name="fecha_inicio" value="<?php echo e(isset($_GET['fecha_inicio'])?$_GET['fecha_inicio']:date('Y-m-d')); ?>" class="form-control">
            </div>
            <label class="col-md-2">Hasta:</label>
            <div class="col-md-4">
                <input type="date" name="fecha_fin" value="<?php echo e(isset($_GET['fecha_fin'])?$_GET['fecha_fin']:date('Y-m-d')); ?>" class="form-control">
            </div>
            <label class="col-md-2">Linea:</label>
            <div class="col-md-10">
                <select class="form-control" name="linea[]" multiple="multiple">
                    <?php $__currentLoopData = $lineas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($obj->id); ?>"><?php echo e($obj->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <label class="col-md-2">Usuario:</label>
            <div class="col-md-10">
                <select class="form-control" name="usuario[]" multiple="multiple">
                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($obj->id); ?>"><?php echo e($obj->nombre); ?> / <?php echo e($obj->ncedula); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <label class="col-md-2">Documento:</label>
            <div class="col-md-10">
                <select class="form-control" name="documento[]" multiple="multiple">
                    <?php $__currentLoopData = $documentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($obj->id); ?>"><?php echo e($obj->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div><br>
            <div class="col-md-12">
                <input type="submit" value="Consultar" class="btn btn-success">
                <br><br>
            </div>
        </form>

        
    </div>

    <div class="col-md-7 row">
        <div class="panel panel-warning col-md-12" >
            <!-- Default panel contents -->
            <div class="panel-heading row" >
                <h5 class="col-md-12">Resultado busqueda</h5>            
            </div>
            <div class="panel-body" >
                <p>
                    Colocar algun filtro de busqueda
                </p>
                <div style="overflow-x:scroll;">
                    <table class="table table-hover" id="datos">
                        <thead>
                            <tr>
                                <th>Ncedula</th>
                                <th>Nombre</th>                                 
                                <th>Linea</th> 
                                <th>Referencia</th> 
                                <th>Precio Und.</th> 
                                <th>Cantidad</th>
                                <th>Total</th>
                                <th>Documento</th> 
                                <th>Número</th> 
                                <th>Nit cliente</th> 
                                <th>Razón social</th> 
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($kardex!=null): ?>
                                <?php $__currentLoopData = $kardex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="background: #ededed"><?php echo e($obj['ncedula']); ?></td>
                                        <td style="background: #ededed"><?php echo e($obj['usuarionombre']); ?></td>                                    
                                        <td><?php echo e($obj['lineasdescripcion']); ?></td>
                                        <td><?php echo e($obj['referenciasdescripcion']); ?></td>
                                        <td><?php echo e($obj['precio']); ?></td>
                                        <td><?php echo e($obj['cantidad']); ?></td>
                                        <td><?php echo e($obj['preciototal']); ?></td>
                                        <td style="background: #b7deed"><?php echo e($obj['documentosnombre']); ?></td>
                                        <td style="background: #b7deed"><?php echo e($obj['numero']); ?> <?php echo e($obj['prefijo']); ?></td>
                                        <td style="background: #b7deed"><?php echo e($obj['nit']); ?></td>
                                        <td style="background: #b7deed"><?php echo e($obj['razon_social']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div id="chart"></div>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
    $(document).ready( function () {
        $('#datos').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ] 
        });
    });
</script>    


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>