<?php $__env->startSection('content'); ?>

<?php 

$referencia = App\Referencias::where('id','=',$kardex[0]->id_referencia->id)->first();

?>


<div class="enc-article">
    <h4 class="title">Kardex <small style="color:#99f;">Código: </small> <?php echo e($referencia->codigo_linea . $referencia->codigo_letras . $referencia->codigo_consecutivo); ?></h4>
</div>


<br><br><br>
<div class="row top-11-w">
  <div class="col-md-11 row" style="overflow-x:scroll;margin-left:2%">
    <p>Información de kardex para el producto <h4 class="title">Saldo: <?php echo e($referencia->saldo); ?></h4></p>
    <table class="table table-hover table-striped" id="datos">
        <thead>
        <tr>
            <th>Id</th>
            <th>Documento</th>
            <th>Sucursal</th>
            <th>#</th>
            <th>Tercero</th>
            <th>cantidad</th>
            <th>Saldo</th>
        </tr></thead>
        <tbody>
            <tr>
                <td>0</td>
                <?php $cont = 0; $total = 0; ?>
                <td>na</td>
                <td>na</td>
                <td>na</td>
                <td><?php echo e($cont); ?></td>
                <td><?php echo e($total); ?></td>
                <td>0</td>
            </tr>
           <?php $__currentLoopData = $kardex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php 

           if($obj->signo == "+"){
                   $cont = $cont + $obj->cantidad;
                   $total = $total + ( -($obj->total*2)+ $obj->total);
           }
           else if($obj->signo == "-"){
                   $cont = $cont - $obj->cantidad;
                   $total = $total - ( -($obj->total*2)+ $obj->total);
           }
           else{
                   $cont = $cont;
                   $total = $total;
           }

           ?>
               <td><?php echo e($obj->id); ?></td>
               <td><?php echo e($obj->id_documento->nombre); ?> <?php echo e(' Pref. '. $obj->prefijo); ?></td>
               <td><?php echo e($obj->id_sucursal->nombre); ?></td>
               <td><a href="javascript:envioUrl('/documentos/imprimir/<?php echo e($obj->cabecera[0]->id); ?>')"><?php echo e($obj->numero); ?></a></td>
               <td><?php echo e($obj->cabecera[0]->id_tercero); ?></td>
               <td><?php echo e(number_format($obj->cantidad)); ?></td>
               <td><?php echo e(number_format($cont)); ?></td>	
            </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <?php echo e($kardex->links()); ?>

    </table>

  </div>
  
</div>

<script>
$(document).ready( function () {
    $('#datos').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ] 
    });
} );
</script>

<script language=javascript>
function envioUrl (url){
window.open(url, "imprimir documento", "width=600, height=500")
}
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>