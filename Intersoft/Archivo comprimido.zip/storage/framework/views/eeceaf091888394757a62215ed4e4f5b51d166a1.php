<?php $__env->startSection('content'); ?>


<script src="/js/vkbeautify.js"></script>

<style>
.title{
    margin-left: 2%;
    font-weight: bold;
    font-family: Poppins;
}
.top-5-w{
    margin-top:5%;
}
.table > thead th {
    -webkit-animation: pantallain 100s infinite; /* Safari 4.0 - 8.0 */
    -webkit-animation-direction: alternate; /* Safari 4.0 - 8.0 */
    animation: pantallain 100s infinite;
    animation-direction: alternate;
}
.red{
    background: #ff4a55;
    color: white;
}
</style>

<div class="enc-article">
    <h4 class="title">Facturatech</h4>
</div>

<div class="row top-5-w">
    <p style="font-size:10pt;font-family:Poppins;margin-left:2%">Envíe las facturas a la DIAN por medio del servicio de Facturatech</p>
    <div style="margin-left: 5%;">
        <form method="GET" class="row">
            <div class="col-md-2">
                <input type="text" name="nit" placeholder="Nit" value="<?php echo e(isset($_GET['nit'])?$_GET['nit']:''); ?>" class="form-control">
            </div>
            <div class="col-md-4">
                <div class="col-md-12 row">
                    <div class="col-md-8">
                        <input type="text" name="razonsocial" value="<?php echo e(isset($_GET['razonsocial'])?$_GET['razonsocial']:''); ?>" placeholder="Razón social" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <select class="form-control" name="vendedor" id="vendedor"> 
                            <option value="">Vendedor</option>
                            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($obj['id']); ?>"><?php echo e($obj['nombre']); ?> <?php echo e($obj['apellido']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 row">
                <div class="col-md-6">
                    <input type="date" name="fechainicio" value="<?php echo e(isset($_GET['fechainicio'])?$_GET['fechainicio']:date('Y-m-d')); ?>" class="form-control">
                </div>
                <div class="col-md-6">
                    <input type="date" name="fechafinal" value="<?php echo e(isset($_GET['fechafinal'])?$_GET['fechafinal']:date('Y-m-d')); ?>" class="form-control">
                </div>
            </div>
            <div class="col-md-2">
                <input type="submit" value="Consultar" class="btn btn-success">
            </div>
        </form><br><br>
    </div>
    <div class="col-md-11" style="overflow-x:scroll;margin-left:2%">
        <table class="table table-hover table-striped"  id="datos">
            <thead>
                <th></th>
                <th></th>
                <th>Sucursal</th>
                <th>#</th>
                <th>Nit</th>
                <th>Nombre</th>
                <th>Fecha Emisión</th>
                <th>Fecha Vencimiento</th>
                <th>total</th>
                <th>Estado</th>
                <th>Vendedor</th>
                <th>Fecha creado</th>
            </tr></thead>
            <tbody>
                <?php $__currentLoopData = $factura; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><div onclick="facturatech.xml('<?php echo e($obj); ?>')"  class="btn btn-warning"><i style="font-size: 12px;" class="fas fa-file-alt"></i></div></td>
                    <td><div onclick="facturatech.send('<?php echo e($obj); ?>')" class="btn btn-danger"><i style="font-size: 12px;" class="fas fa-file-import"></i></div></td>
                    <td><div style="width: 150px;"><?php echo e($obj['sucunombre']); ?></div></td>
                    <td><a href="javascript:envioUrl('/documentos/imprimir/<?php echo e($obj['idfactura']); ?>')" ><?php echo e($obj['numero']); ?></a></td>
                    <td><?php echo e($obj['id_tercero']); ?></td>
                    <td><div style="width: 200px;"><?php echo e($obj['nombrecliente']); ?></div></td>
                    <td><?php echo e($obj['fecha']); ?></td>
                    <td><?php echo e($obj['fecha_vencimiento']); ?></td>
                    <td><?php echo e(number_format($obj['total'])); ?></td>
                    <td><?php echo e($obj['estadofactura']); ?></td>
                    <td><?php echo e($obj['nombrevendedor']); ?> <?php echo e($obj['apellido']); ?></td>
                    <td><div style="width: 150px;"><?php echo e($obj['creado']); ?></div></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
            </tbody>
        </table>
        
    </div>
    
</div>




<script>
$(document).ready( function () {
    $('#datos').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ] 
    });
} );

var facturatech = new Facturatech();

facturatech.init();

function Facturatech(){
    this.init = function(){
        $('#btn_modal').hide();
    }

    this.xml = function(obj){
        factura  = JSON.parse(obj);
        //console.log(factura);
        //enviar id al servicio xml 
        var URL = "/facturacion/facturatech/"+factura.idfactura+"/xml";
        var parametros = {
            "id" : factura.idfactura,
        };
        $.ajax({
			data:  parametros,
			url:   URL,
			type:  'get',
			beforeSend: function () {
				$('#resultado').html('<p>Espere porfavor</p>');
			},
			success:  function (response) {
                console.log(response);
                var sXML = new XMLSerializer().serializeToString(response); 
                sXML = vkbeautify(sXML, 'xml');
                document.getElementById("DivXml").innerText = sXML;
                $('#btn_modal').trigger('click');

                function download(filename, text) {
                    var element = document.createElement('a');
                    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
                    element.setAttribute('download', filename);
                    element.style.display = 'none';
                    document.body.appendChild(element);
                    element.click();
                    document.body.removeChild(element);
                }
                download('Factura.xml', sXML);
			}
        });
    }
}
</script>

<!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" id="btn_modal" data-target="#myModal">Open Modal</button>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">XML Generado</h4>
      </div>
      <div class="modal-body" style="overflow-y: scroll; height: 300px;">
        <p>Este es el resultado del XML</p>
        <pre>
            <code>
                <div id="DivXml"></div>
            </code>
        </pre>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>