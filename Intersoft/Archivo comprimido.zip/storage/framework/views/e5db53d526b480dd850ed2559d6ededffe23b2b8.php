<html>
    <style type="text/css">
        * { -webkit-print-color-adjust: exact; }

@media  print {
    
    h3, thead tr{
        background: #207ce5 !important;
        color:white !important;
        padding:2%;
    }
    
}


.separador { page-break-after: auto; }
    </style>
<body>
    <link href="/assets/css/bootstrap.min.css" rel="stylesheet"  />
    <?php $empresa = App\Empresas::where('id','=',Session::get('id_empresa'))->first(); ?>
    <?php $lineas = App\Lineas::where('id_empresa','=',Session::get('id_empresa'))->whereIn('id',$vistalineas)->get(); ?>
    <div class="jumbotron text-center">
        <h1>Catalogo de productos</h1>
        <h2><?php echo e($empresa->razon_social); ?></h2>
    </div>

    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $lineas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="separador"></div>
            <div class="col-sm-12" style="text-align: center;">
                <h3><?php echo e($linea->nombre); ?></h3>
                <hr>
                <table class="table">
                    <thead>
                        <tr style="background: #207ce5;color:white;padding:2%;">
                            <th>Código</th>
                            <th>Descripción</th>
                            <th>Precio</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($linea->id == $ref['codigo_linea']): ?>
                            <tr>
                                <td style="text-align: left"><?php echo e($ref['codigo_barras']); ?></td>
                                <td style="text-align: left"><?php echo e($ref['descripcion']); ?></td>
                                <td style="text-align: right">$ <?php echo number_format($ref['precio'], 0, ",", "."); ?></td>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</body>


<script>
    window.print();
</script>

</html>
