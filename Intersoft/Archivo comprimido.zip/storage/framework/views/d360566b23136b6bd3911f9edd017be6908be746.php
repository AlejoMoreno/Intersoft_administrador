<?php $__env->startSection('content'); ?>

<form action="/invitados/create" method="POST">
    <input type="email" class="form-control" name="correo" id="correo" placeholder="Correo">
    <input type="text" class="form-control" name="nombre" id="nombre" placeholder="Nombre">
    <input type="hidden" class="form-control" value="<?php echo e($calendario['id']); ?>" name="id_calendario" id="id_calendario" >
    <input type="hidden" class="form-control" value="1" name="id_directorio" id="id_directorio">
    <input type="submit" value="Enviar" class="btn">
</form>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>