<?php $__env->startSection('content'); ?>


<div class="container-fluid">
    <div class="row">

        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h4 class="title">Tipo Pagos</h4>
                    <p class="category">Diferentes pagos</p><br>
                </div>
                <div class="content">
                    <div style="overflow-x:scroll;overflow-y:scroll;height:500px;">
                        <table class="table table-hover table-striped" id="datos">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre
                                    <th>Cuenta Contable</th>
                                    <th>Cuenta Descripción</th>
                                    <th>Nit</th>
                                    <th>Razon social</th>
                                    <th></th> 
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $tipopagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="row<?php echo e($obj['id']); ?>">
                                        <td><?php echo e($obj['id']); ?></td>
                                        <td><?php echo e($obj['nombre']); ?></td>
                                        <td><?php echo e($obj['puc_cuenta']['codigo']); ?></td>
                                        <td><?php echo e($obj['puc_cuenta']['descripcion']); ?></td>
                                        <td><?php echo e($obj['tercero']['nit']); ?></td>
                                        <td><?php echo e($obj['tercero']['razon_social']); ?></td>
                                        <td><a href="javascript:;" onclick="tipopagos.update('<?php echo e($obj); ?>');"><button class="btn btn-warning">></button></a></td>
                                        <!--td><a onclick="config.delete_get('/inventario/tipo_presentaciones/delete/', '<?php echo e($obj); ?>',  '/inventario/tipo_presentaciones');" href="#"><button class="btn btn-danger">x</button></a></td-->
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <h4>Crear tipo pagos</h4>
                    
                        <form action='/administrador/tipopagos/create' method="POST" name="formulario" id="formulario">
                            <input type="hidden" name="id" id="id">
                            <div class="row">
                                <div class="col-md-4">
                                    <label>Nombre</label><br>
                                    <input type="text" class="form-control" name="nombre" id="nombre" placeholder="Escribe el nombre" required="" onkeyup="config.UperCase('nombre');">
                                </div>
                                <div class="col-md-4">
                                    <label>Puc Cuenta</label><br>
                                    <select name="puc_cuenta" id="puc_cuenta" class="form-control">
                                        <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($obj['id']); ?>"><?php echo e($obj['codigo']); ?> - <?php echo e($obj['descripcion']); ?></option>        
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label>Tercero Nit</label><br>
                                    <input type="text" list="terceros" class="form-control" name="tercero" id="tercero" placeholder="Escribe la descrioción de esta clasificación" required="" onkeyup="config.UperCase('descripcion');">
                                    <datalist  id="terceros">
                                        <?php $__currentLoopData = $terceros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($obj['id']); ?>"> <?php echo e($obj['nit']); ?> - <?php echo e($obj['razon_social']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </div>
                            </div>


                        <input type="submit" value="Guardar" id="btnguardar" class="btn btn-success form-control">
                        <div id="actualizar" onclick="config.send_post('#formulario', '/administrador/tipopagos/update', '/administrador/tipopagos');" class="btn btn-warning form-control">Actualizar</div>
                        </form>
                    <div id="resultado"></div>
                    <div class="footer">
                        <div class="legend">
                            <i class="fa fa-circle text-info"></i> 
                            <i class="fa fa-circle text-danger"></i> 
                            <i class="fa fa-circle text-warning"></i>
                        </div>
                        <hr>
                        <div class="stats">
                            <i class="pe-7s-angle-left-circle"></i> <a href="#" onclick="config.Redirect('/administrador/index');"> ir atras.</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>

</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>