<?php

namespace App\Facturatech;

use Illuminate\Database\Eloquent\Model;

class FMep extends Model
{
    //
}
