<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
    <title>Recuperación de contraseña</title>
</head>
<body>
    <p>Hola se ha recuperado la contraseña del usuario.</p>
    <p>Estos son los datos del usuario:</p>
    <ul>
        <li>Contraseña: Temporal123</li>
    </ul>
</body>
</html>