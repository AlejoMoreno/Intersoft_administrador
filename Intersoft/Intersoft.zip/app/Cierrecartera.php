<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cierrecartera extends Model
{
    //
}
