<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cierregrupos extends Model
{
    //
}
