<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Puccuentas extends Model
{
    protected $fillable = ['id_pucgrupos','codigo','descripcion'];
}
