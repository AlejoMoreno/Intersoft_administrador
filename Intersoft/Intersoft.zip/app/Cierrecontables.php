<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cierrecontables extends Model
{
    //
}
