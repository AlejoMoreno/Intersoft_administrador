<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pucgrupos extends Model
{
    protected $fillable = ['id_pucclases','codigo','descripcion'];
}
