<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FormaPagos extends Controller
{
    //
}
