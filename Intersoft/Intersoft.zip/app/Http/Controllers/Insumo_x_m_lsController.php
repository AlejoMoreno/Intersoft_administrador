<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Insumo_x_m_lsController extends Controller
{
    //
}
