<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProduccionturnosController extends Controller
{
    //
}
