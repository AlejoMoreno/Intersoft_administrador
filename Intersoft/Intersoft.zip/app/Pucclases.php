<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pucclases extends Model
{
    protected $fillable = ['codigo','descripcion'];
}
