<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cierresubcuentas extends Model
{
    //
}
