<?php

namespace App\Facturatech;

use Illuminate\Database\Eloquent\Model;

class FDfe extends Model
{
    protected $fillable = ['DFE_1',
    'DFE_2',
    'DFE_3',
    'DFE_4',
    'DFE_5',
    'DFE_6',
    'DFE_7',
    'DFE_8',
    'id_empresa'];
}
