<?php

namespace App\Facturatech;

use Illuminate\Database\Eloquent\Model;

class FAdq extends Model
{
    //
}
