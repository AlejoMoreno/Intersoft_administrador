<?php

namespace App\Facturatech;

use Illuminate\Database\Eloquent\Model;

class FIcc extends Model
{
    protected $fillable = ['ICC_1',
    'ICC_2',
    'ICC_3',
    'ICC_4',
    'ICC_5',
    'ICC_6',
    'ICC_7',
    'ICC_8',
    'ICC_9',
    'id_empresa'];
}
