<?php

namespace App\Facturatech;

use Illuminate\Database\Eloquent\Model;

class FCda extends Model
{
    //
}
