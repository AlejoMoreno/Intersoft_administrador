<?php

namespace App\Facturatech;

use Illuminate\Database\Eloquent\Model;

class FTac extends Model
{
    protected $fillable = ['TAC_1',
    'id_empresa'];
}
