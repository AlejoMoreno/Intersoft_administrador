<?php

namespace App\Facturatech;

use Illuminate\Database\Eloquent\Model;

class FGte extends Model
{
    protected $fillable = ['GTE_1',
    'GTE_2',
    'id_empresa'];
}
