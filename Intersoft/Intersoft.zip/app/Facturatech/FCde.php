<?php

namespace App\Facturatech;

use Illuminate\Database\Eloquent\Model;

class FCde extends Model
{
    protected $fillable = ['CDE_1',
    'CDE_2',
    'CDE_3',
    'CDE_4',
    'id_empresa'];
}
