<?php

namespace App\Facturatech;

use Illuminate\Database\Eloquent\Model;

class FEnc extends Model
{
    protected $fillable = ['ENC_1',
    'ENC_2',
    'ENC_3',
    'ENC_4',
    'ENC_5',
    'ENC_6',
    'ENC_7',
    'ENC_8',
    'ENC_9',
    'ENC_10',
    'ENC_11',
    'ENC_12',
    'ENC_13',
    'ENC_14',
    'ENC_15',
    'ENC_16',
    'ENC_17',
    'ENC_18',
    'ENC_19',
    'ENC_20',
    'ENC_21',
    'ENC_22',
    'ENC_23',
    'ENC_24',
    'ENC_25',
    'id_empresa'];
}
