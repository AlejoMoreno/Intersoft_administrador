<?php

namespace App\Facturatech;

use Illuminate\Database\Eloquent\Model;

class FEmi extends Model
{
    protected $fillable = ['EMI_1',
    'EMI_2',
    'EMI_3',
    'EMI_4',
    'EMI_5',
    'EMI_6',
    'EMI_7',
    'EMI_8',
    'EMI_9',
    'EMI_10',
    'EMI_11',
    'EMI_12',
    'EMI_13',
    'EMI_14',
    'EMI_15',
    'EMI_16',
    'EMI_17',
    'EMI_18',
    'EMI_19',
    'EMI_20',
    'EMI_21',
    'EMI_22',
    'EMI_23',
    'EMI_24',
    'EMI_25',
    'id_empresa'];
}
