<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Directorio_tipos extends Model
{
    protected $fillable = ['nombre','descripcion'];
}
