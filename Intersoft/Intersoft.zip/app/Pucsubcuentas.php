<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pucsubcuentas extends Model
{
    protected $fillable = ['id_puccuentas','codigo','descripcion'];
}
