(function() {

    'use strict';

    toastada.setOptions({
        animate: true,
        animateDuration: 200
    });

    // configure toast
    var successBtn = document.querySelector('#suc');
    var infoBtn = document.querySelector('#info');
    var warnBtn = document.querySelector('#warn');
    var errorBtn = document.querySelector('#err');

    

})();
